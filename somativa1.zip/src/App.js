import React, {Component} from 'react';
import './App.css';
class App extends Component{
  constructor(props){
    super(props);
    this.state = {
      email: '',
      senha: '',
      mensagem: ''
    };
    

    this.muda = this.muda.bind(this);
    this.fazerLogin = this.fazerLogin.bind(this);
  }

  muda(event){
    const {name,value} = event.target;
    this.setState({
      [name]: value

    });
    console.log(name,value);
  }
  fazerLogin(event){
    event.preventDefault();
    const email = "eduardo.lino@pucpr.br";
    const senha = "123456";

    if (this.state.email == email && this.state.senha == senha){
      this.setState({
        mensagem: "Acessado com sucesso!"
      });
    } else {
      this.setState({
        mensagem: "Usuário ou senha incorretos!"
      });
    }
  }
  renderizaMensagem(){

    if (this.state.mensagem === ''){
      return null;
    }
    return(
      <p>
        {this.state.mensagem}
      </p>
    );
  }

  

 render(){
  return(
    <div>
      <h1>Login</h1>
      <form onSubmit={this.fazerLogin}>
        <input type="text" size="25" name="email" value={this.state.email} onChange={this.muda}/><br></br>
        <input type="password" size="25" name="senha" value={this.state.senha} onChange={this.muda}/><br></br>
        <button type="submit">Acessar</button>
      </form> 
      {this.renderizaMensagem()}
      </div>
  );
 }
}

export default App;
